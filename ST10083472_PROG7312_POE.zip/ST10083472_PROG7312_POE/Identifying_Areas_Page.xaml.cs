﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ST10083472_PROG7312_POE
{
    public partial class Identifying_Areas_Page : Window
    {
        //______________________________________________
        //------------Code Attribution:-----------------
        //Author: TutorialsTeacher
        //Link: https://www.tutorialsteacher.com/csharp/csharp-dictionary
        //______________________________________________
        private Dictionary<string, string> deweyCategories = new Dictionary<string, string>
        {
            { "001.34 SMR", "Science of Magic: A Comprehensive Guide" },
            { "123.45 JHN", "Adventures in Time Travel: John's Perspective" },
            { "345.67 FRY", "Culinary Chemistry: Recipes from the Fryer" },
            { "456.78 WLL", "Art of Illusion: A Masterpiece by William" },
            { "600.89 LWS", "The World of Robotics: A Journey with Linda" },
            { "789.12 BKS", "Musical Notes: The Life of Composer Brenda" },
            { "823.45 KNG", "Mystery Tales: The Enigmatic Stories of King" },
            { "900.67 PTT", "Exploring the Universe: An Odyssey by Peter" },
            { "999.99 XYZ", "The Uncharted Realm: A Fictional Adventure" },
            { "333.33 LEE", "Wildlife Wonders: Encounters with Lee's Creations" }
        };

        //Variables
        private List<string> callNumbers = new List<string>();
        private List<string> descriptions = new List<string>();
        private Random random = new Random();
        private bool matchingDescriptionsToCallNumbers = true;
        private List<string> associations = new List<string>();
        private string selectedCallNumber;
        private string selectedDescription;
        private HashSet<string> usedCallNumbers = new HashSet<string>(); // keeps track of used call numbers.
        private List<string> ehudfs = new List<string>(); // keeps track of all associations.
        private bool isDescriptionToCallNumberMode = false;  // Keeps track of mode swap

        public Identifying_Areas_Page()
        {
            InitializeComponent();
            try
            {
                PopulateLists();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in initialization: " + ex.Message);
            }
        }

        private void PopulateLists()
        {
            try
            {
                // Clears items.
                callNumbers.Clear();
                descriptions.Clear();

                //______________________________________________
                //------------Code Attribution:-----------------
                //Author: Microsoft
                //Link: https://learn.microsoft.com/en-us/dotnet/csharp/programming-guide/concepts/linq/introduction-to-linq-queries
                //______________________________________________
                if (isDescriptionToCallNumberMode)
                {
                    // Selects 4 unique random descriptions from Dictionary.
                    var selectedDescriptions = deweyCategories.Values.OrderBy(x => random.Next()).Distinct().Take(4).ToList();
                    descriptions = selectedDescriptions;

                    // Gets the correct call numbers for the selected descriptions.
                    var correctCallNumbers = deweyCategories.Where(pair => selectedDescriptions.Contains(pair.Value))
                                                            .Select(pair => pair.Key).ToList();

                    // Adds 3 incorrect call numbers
                    var remainingCallNumbers = deweyCategories.Keys.Except(correctCallNumbers).ToList();
                    var incorrectCallNumbers = remainingCallNumbers.OrderBy(x => random.Next()).Take(3).ToList();

                    // Concatenation and shuffels
                    callNumbers = correctCallNumbers.Concat(incorrectCallNumbers).OrderBy(x => random.Next()).ToList();
                }
                else
                {

                    callNumbers = deweyCategories.Keys.OrderBy(x => random.Next()).Distinct().Take(4).ToList();
                    var correctDescriptions = callNumbers.Select(num => deweyCategories[num]).ToList();
                    var remainingDescriptions = deweyCategories.Values.Except(correctDescriptions).ToList();
                    var incorrectDescriptions = remainingDescriptions.OrderBy(x => random.Next()).Take(3).ToList();

                    descriptions = correctDescriptions.Concat(incorrectDescriptions).OrderBy(x => random.Next()).ToList();
                }

                // Adds to lists
                lb_Call_Numbers.ItemsSource = callNumbers;
                lb_Descriptions.ItemsSource = descriptions;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error populating lists: " + ex.Message);
            }
        }

        private void SwapMatchingMode()//Method for swapping
        {
           
            var temp = callNumbers;
            callNumbers = descriptions;
            descriptions = temp;

            // Updates listbox with new values
            lb_Call_Numbers.ItemsSource = null; 
            lb_Call_Numbers.ItemsSource = callNumbers;

            lb_Descriptions.ItemsSource = null; 
            lb_Descriptions.ItemsSource = descriptions;
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)//Returns to home page
        {
            Close();
            MainWindow main = new MainWindow();
            main.Show();
        }

        private void btn_New_Close_Click(object sender, RoutedEventArgs e)//closes app
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)//start up method
        {
            try
            {
                PopulateLists();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error on window load: " + ex.Message);
            }
        }

        private void btn_Check_Answers_Click(object sender, RoutedEventArgs e)//check answers button
        {
            try
            {
                CheckAnswers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking answers: " + ex.Message);
            }
        }

        private void CheckAnswers()//checks answers method
        {
            try
            {
                // Checks if < 4 associations 
                if (associations.Count < 4)
                {
                    lbl_Progress.Content = "Please make 4 associations before checking answers.";
                    pb_Answers.Value = 0; //resets progress bar
                    return;
                }

                int correctAnswers = 0;

                // Checks each association
                foreach (var association in associations)
                {
                    var parts = association.Split('-').Select(p => p.Trim()).ToList();
                    if (parts.Count == 2)
                    {
                        string callNumber = parts[0];
                        string description = parts[1];

                        // Check if the description matches
                        if (deweyCategories.TryGetValue(callNumber, out var correctDescription) && correctDescription == description)
                        {
                            correctAnswers++;
                        }
                    }
                }
                if (correctAnswers == 4)
                {
                    lbl_Progress.Content = "All associations are correct! Well done!";
                    pb_Answers.Value = 100;
                    MessageBox.Show("Congratulations! All your associations are correct! Starting a new game...", "Well Done!", MessageBoxButton.OK, MessageBoxImage.Information);
                    StartNewGame(); // Starts new game if they get all correct
                }
                else
                {
                    lbl_Progress.Content = $"{correctAnswers} out of 4 associations are correct. Try again!";
                    pb_Answers.Value = (correctAnswers * 25);// calculates progress bar value
                }

                // Clears lists
                usedCallNumbers.Clear();
                associations.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in answer verification: " + ex.Message);
            }
        }


        private void btn_New_Game_Click(object sender, RoutedEventArgs e)//new game button
        {
            try
            {
                StartNewGame();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error starting new game: " + ex.Message);
            }
        }

        private void StartNewGame()//start new game method
        {
            try
            {
                // Clears data
                associations.Clear();
                usedCallNumbers.Clear();
                lb_Call_Numbers.SelectedItem = null;
                lb_Descriptions.SelectedItem = null;
                lb_Answers.Items.Clear();
                pb_Answers.Value = 0;
                lbl_Progress.Content = string.Empty;

                PopulateLists();//calls the populatelists method
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in starting new game: " + ex.Message);
            }
        }

        private void Btn_Swap_Click(object sender, RoutedEventArgs e)
        {
            // Swaps modes
            isDescriptionToCallNumberMode = !isDescriptionToCallNumberMode;

            // Clears data
            usedCallNumbers.Clear();
            associations.Clear();
            lb_Call_Numbers.SelectedItem = null;
            lb_Descriptions.SelectedItem = null;
            lb_Answers.Items.Clear();
            pb_Answers.Value = 0;
            lbl_Progress.Content = string.Empty;

            //calls the populatelists method
            PopulateLists();
        }

        private void lb_Call_Numbers_SelectionChanged(object sender, SelectionChangedEventArgs e)//used for item selection
        {
            if (lb_Call_Numbers.SelectedItem != null)
            {
                selectedCallNumber = lb_Call_Numbers.SelectedItem.ToString();
            }
        }

        private void lb_Descriptions_SelectionChanged(object sender, SelectionChangedEventArgs e)//used for item selection
        {
            if (lb_Descriptions.SelectedItem != null)
            {
                selectedDescription = lb_Descriptions.SelectedItem.ToString();
            }
        }

        private void btn_Associate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lb_Call_Numbers.SelectedItem == null || lb_Descriptions.SelectedItem == null)
                {
                    //error handling
                    MessageBox.Show("Please select one item from both list boxes to associate.");
                    return;
                }

                string selectedCallNumber = lb_Call_Numbers.SelectedItem.ToString();
                string selectedDescription = lb_Descriptions.SelectedItem.ToString();

                if (usedCallNumbers.Contains(selectedCallNumber))
                {
                    // checks if it is already in use
                    MessageBox.Show("This call number has already been used. Please select a different call number.");
                    return;
                }

                if (associations.Count >= 4)
                {
                    // checks if max of 4 has been reached
                    MessageBox.Show("You cannot associate more than 4 pairs. Please check your answers now.");
                    return;
                }

                // adds selected items to list
                associations.Add($"{selectedCallNumber} - {selectedDescription}");
                usedCallNumbers.Add(selectedCallNumber);
                lb_Answers.Items.Add($"{selectedCallNumber} - {selectedDescription}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating association: " + ex.Message);
            }
        }

        private void btn_Restart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ResetAssociations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in reset: " + ex.Message);
            }
        }
        private void ResetAssociations()
        {
            try
            {
                //clears data
                lb_Answers.Items.Clear();
                usedCallNumbers.Clear();
                associations.Clear();

                // Informs the user that they can start over.
                lbl_Progress.Content = "You can retry associating the items.";
                pb_Answers.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error resetting associations: " + ex.Message);
            }
        }

        private void btn_Help_Click(object sender, RoutedEventArgs e)
        {
            string helpMessage = "In this game, you need to match book descriptions with the correct call numbers.\n\n" +
                       "1. Associate: Select one item from both the 'Call Numbers' and 'Descriptions' list boxes, then click 'Associate' to create a match. Try to find the correct pairings!\n\n" +
                       "2. Check Answers: After making associations, click 'Check Answers' to see if you've matched the items correctly. You need to make 4 correct associations to win.\n\n" +
                       "3. New Game: Starts a new game with a fresh set of call numbers and descriptions. All your progress will be reset.\n\n" +
                       "4. Restart: Clears all your current associations, allowing you to start over without changing the existing call numbers and descriptions.\n\n" +
                       "5. Back: Allows you to return to the main menu.\n\n" +
                       "6. Close: Exits the application.\n\n" +
                       "7. Help: You're already here! This provides information on how to play the game.";

            MessageBox.Show(helpMessage, "Help", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}

