﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ST10083472_PROG7312_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void btn_Replacing_Books_Click(object sender, RoutedEventArgs e)
        {
            this.Hide(); //Hides Main Form
            Replacing_Books_Page replace_books = new Replacing_Books_Page(); 
            replace_books.Show();//Shows Replace Books Page
        }

        private void btn_Close_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();// Closes application
        }

        private void btn_Identifying_Areas_Click(object sender, RoutedEventArgs e)
        {
            this.Hide(); //Hides Main Form
             Identifying_Areas_Page Identify_page = new Identifying_Areas_Page();
            Identify_page.Show();//Shows Identifying Areas Page
        }
    }
}
