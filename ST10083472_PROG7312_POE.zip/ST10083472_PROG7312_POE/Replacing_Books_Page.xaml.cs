﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10083472_PROG7312_POE
{
    /// <summary>
    /// Interaction logic for Replacing_Books_Page.xaml
    /// </summary>
    public partial class Replacing_Books_Page : Window
    {
        private List<string> generatedCallNumbers = new List<string>(); //Array List to store generated call numbers
        private List<string> sortedCallNumbers = new List<string>(); //Array List to store sorted call numbers
        private int correctOrderCount = 0; //used in methods
        private int totalCallNumbers = 10; //used in methods

        public Replacing_Books_Page()
        {
            InitializeComponent();
        }

        private void btn_Retry_Click(object sender, RoutedEventArgs e)
        {
            lb_Display_Users_Answers.Items.Clear();//clears listbox
            pb_Answers.Value = 0;//resets value of progress bar to 0
            lbl_Progress.Content = "Let's get started"; //resets label
        }

        private void GenerateRandomCallNumbers()
        {
            Random random = new Random();//calls random operator
            generatedCallNumbers.Clear(); // Clear the list to remove previous call numbers

            for (int i = 0; i < 10; i++)//start for
            {
                string integerPart = random.Next(1000).ToString("000");//generates random 3 digit integer
                string decimalPart = random.Next(100).ToString("00");//generates random 2 digit decimal value
                string surnameAbbreviation = GenerateRandomSurname();//calls generate surname method
                string callNumber = $"{integerPart}.{decimalPart} {surnameAbbreviation}";//concatinates the values to create a random call number

                generatedCallNumbers.Add(callNumber); // Add new call numbers to the list
            }//end for
        }

        private string GenerateRandomSurname() //method to generate the random 3 letters of the authors surname
        {
            Random random = new Random();//calls random operator
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //stores all letters for random picking

            //______________________________________________
            //------------Code Attribution:-----------------
            //Author: Darin Dimitrov
            //Link: https://stackoverflow.com/questions/3132126/how-do-i-select-a-random-value-from-an-enumeration
            //______________________________________________
            return new string(Enumerable.Repeat(letters, 3)
                .Select(s => s[random.Next(s.Length)]).ToArray()); //returns a random 3 letter surname
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)//Window load event
        {
            GenerateRandomCallNumbers();//calls the generate random surname method
            populateListBox();//calls the populate list method
            lbl_Progress.Content = "Let's get started!";//resets label text
        }


        private void populateListBox()//Populates the list Method Start
        {
            for (int i = 0; i < 10; i++)//start For
            {
                lb_Generate_Call_Numbers.Items.Add(generatedCallNumbers[i]);//add callnumbers from array to listbox
            }//end for
        }

        private void lb_Generate_Call_Numbers_SelectionChanged(object sender, SelectionChangedEventArgs e)//event to extract users selection
        {
            if (lb_Generate_Call_Numbers.SelectedIndex != -1)//start If
            {
                string selectOption = lb_Generate_Call_Numbers.SelectedItem.ToString();
                lb_Display_Users_Answers.Items.Add(selectOption);//adds selection to other list box
            }//end If
        }

        private void btn_Check_Answers_Click(object sender, RoutedEventArgs e)
        {
            try
            {//try catch start
             // Splits the generated call numbers into their components and sorts them.
             //______________________________________________
             //------------Code Attribution:-----------------
             //Author: xing
             //Link: https://stackoverflow.com/questions/13135777/how-to-sort-the-array-list-by-subsequent-number-in-wpf#:~:text=The%20more%20generic%20and%20flexible,can%20order%20the%20strings%20correctly.
             //______________________________________________
                sortedCallNumbers = generatedCallNumbers
                    .OrderBy(call => call)
                    .ToList();

                // Get the user's answers from the second ListBox.
                List<string> userAnswers = lb_Display_Users_Answers.Items.Cast<string>().ToList();

                // Checks if the user's answers match the sorted call numbers.
                correctOrderCount = 0;
                for (int i = 0; i < userAnswers.Count; i++)//start For
                {
                    if (userAnswers[i] == sortedCallNumbers[i])//start If
                    {
                        correctOrderCount++;
                    }//end If
                }//end For
                int percentage = (correctOrderCount * 100) / totalCallNumbers;

                // Display a message based on the user's performance.
                if (percentage == 100)//Start If
                {
                    MessageBox.Show("Congratulations! You sorted all call numbers correctly.", "Success");
                }
                else
                {
                    MessageBox.Show($"You sorted {correctOrderCount} out of {totalCallNumbers} call numbers correctly.", "Results");
                }
                UpdateProgressBar();//calls method to update progress bar
            }//end If
            catch (Exception ex)
            {
                // Handle exceptions, such as an incorrect number of call numbers.
                MessageBox.Show("Looks Like The Values You Entered Are Invalid, Please Review Your Answers Or Click The Retry Button. Thank You :P");
                MessageBox.Show("Error: " + ex.Message);
            }//end Catch
        }// Button End

        private void UpdateProgressBar()//method to update progress bar
        {
            // Calculate the percentage of correctly ordered call numbers.
            int percentage = correctOrderCount * 10;

            // Update the label content with different messages based on the progress.
            if (percentage == 0)
            {
                lbl_Progress.Content = "Let's get started!";
            }
            else if (percentage < 100)
            {
                lbl_Progress.Content = $"Sorting Progress: {percentage}%";
            }
            else
            {
                lbl_Progress.Content = "All Call Numbers Sorted!";
                MessageBox.Show("Congratulations!, You Have Successfully Sorted All The Call Numbers Correctly, Please Click The New Game Button To Play Again or Exit The Application By Clicking The X Button. Thank You :P");
            }

            pb_Answers.Value = percentage;//updates progress bar according to percentage calculated
        }

        private void lb_Display_Users_Answers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void StartNewGame() //method to regenerate new call numbers for new game
        {
                // Clears the ListBoxes to remove previous answers and call numbers.
                lb_Display_Users_Answers.Items.Clear();
                lb_Generate_Call_Numbers.Items.Clear(); // Clear the list box here
                lbl_Progress.Content = "Let's get started!";

            // Reset the game state and update the progress bar.
            correctOrderCount = 0;
                pb_Answers.Value = 0;

                // Generates new call numbers and populate the list box.
                GenerateRandomCallNumbers();//calls method generate Call numbers
                populateListBox(); //calls populates List box
        }

        private void btn_New_Game_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("A New Game Has Begun, Good Luck :P"); 
            StartNewGame();//calls start new game method
        }

        private void btn_New_Close_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();//closes application
        }

        private void btn_Undo_Click(object sender, RoutedEventArgs e)
        {
            // Check if there are items in the lb_Display_Users_Answers ListBox.
            if (lb_Display_Users_Answers.Items.Count > 0)
            {
                // Remove the most recent item from the ListBox.
                lb_Display_Users_Answers.Items.RemoveAt(lb_Display_Users_Answers.Items.Count - 1);
            }
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            Replacing_Books_Page replacing = new Replacing_Books_Page();
            replacing.Close();//closes replacing books page

            MainWindow main = new MainWindow();
            main.Show();//shows main form
        }

        private void btn_Help_Click(object sender, RoutedEventArgs e)
        {
            //Displays a help message to guide users on how to use the system
            string helpMessage = "To order the call numbers, the user will have to select the correct " +
                                 "call number in the provided list box, by clicking on the item in the listbox " +
                                 "the user will be able to automatically enter the selected item in the right listbox " +
                                 "which will be sorted and validated.\n\n" +
                                 "Help: Instructions on how to use the system.\n\n" +
                                 "Check Answers: Check if your call numbers are in the correct order.\n\n" +
                                 "Undo: Remove the most recently added call number.\n\n" +
                                 "New Game: Start a new game with a fresh set of call numbers.\n\n" +
                                 "Back: Allows the user to return to the main page.\n\n" +
                                 "Close: Close the application.";

            MessageBox.Show(helpMessage, "Help", MessageBoxButton.OKCancel, MessageBoxImage.Information);
        }
    }
}